import controller.DAOEquipo;
import controller.DAOLiga;
import controller.DAOPartido;
import model.Equipo;
import model.Liga;
import model.Partido;

public class Entrada {
    public static void main(String[] args) {
        DAOLiga operacionLiga = new DAOLiga();
        DAOPartido operacionPartido = new DAOPartido();
        DAOEquipo operacionEquipo = new DAOEquipo();
        operacionLiga.crearLiga(new Liga("Primera","11/08/23","26/05/24"));
        //operacionLiga.editarLiga(new Liga(2,"primera","oleee","264"));
        //operacionLiga.eliminarLiga(new Liga(23));
        /*operacionEquipo.registrarEquipo(new Equipo("matusalen","Zamora"));
        operacionEquipo.registrarEquipo(new Equipo("UDS","Salamanca"));
        operacionEquipo.registrarEquipo(new Equipo("Los Santos","GTA San Andreas"));
        operacionEquipo.registrarEquipo(new Equipo("Osasuna","A saber"));
        operacionEquipo.registrarEquipo(new Equipo("Atleti","Madrid"));
        operacionEquipo.registrarEquipo(new Equipo("Rvallecano","Madrid"));
        operacionEquipo.registrarEquipo(new Equipo("Sanse","Madrid"));
        operacionEquipo.registrarEquipo(new Equipo("ManceraFC","Mancera de abajo"));*/
        operacionEquipo.eliminarEquipo(new Equipo(26));
        /*operacionEquipo.eliminarEquipo(new Equipo(20));
        operacionEquipo.eliminarEquipo(new Equipo(21));
        operacionEquipo.eliminarEquipo(new Equipo(22));
        operacionEquipo.eliminarEquipo(new Equipo(23));*/
        operacionPartido.regisatrarPartido(new Partido("02/03/25",5,3));
        operacionPartido.regisatrarPartido(new Partido("02/04/25",5,3));
        operacionPartido.regisatrarPartido(new Partido("02/05/25",5,3));
        operacionPartido.regisatrarPartido(new Partido("02/06/25",5,3));







    }
}

package model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table (name="equipos")

public class Equipo implements Serializable {
    @ManyToOne
    @JoinColumn(name = "id_liga")
    private Liga liga;

    @OneToMany(mappedBy = "equipoLocal", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Partido> partidosLocal;

    @OneToMany(mappedBy = "equipoVisitante", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Partido> partidosVisitante;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_equipo;

    @Column
    private String nombre_equipo;

    @Column
    private String ciudad;


    // Constructor para registrar nuevos equipos.
    public Equipo(String nombre_equipo, String ciudad) {
        this.nombre_equipo = nombre_equipo;
        this.ciudad = ciudad;
    }


    // Constructor para modificar información de equipos existentes.
    public Equipo(int id_equipo, String nombre_equipo, String ciudad) {
        this.id_equipo = id_equipo;
        this.nombre_equipo = nombre_equipo;
        this.ciudad = ciudad;
    }

    // Constructor para eliminar equipos de una liga.
    public Equipo(int id_equipo) {
        this.id_equipo = id_equipo;
    }


}

package model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name="ligas")

public class Liga implements Serializable {
    @OneToMany(mappedBy = "liga", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Equipo> equipos;

    @OneToMany(mappedBy = "liga", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Partido> partidos;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_liga;

    @Column
    private String nombre_liga;

    @Column
    private String fecha_inicio;

    @Column
    private String fecha_fin;

    // Constructor para crear nueva liga.
    public Liga(String nombre_liga, String fecha_inicio, String fecha_fin) {
        this.nombre_liga = nombre_liga;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
    }

    // Constructor para editar información de una liga existente.
    public Liga(int id_liga, String nombre_liga, String fecha_inicio, String fecha_fin) {
        this.id_liga = id_liga;
        this.nombre_liga = nombre_liga;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
    }
    public Liga(int id_liga){
        this.id_liga = id_liga;
    }
}

package model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity

@Table(name="partidos")

public class Partido implements Serializable {
    @ManyToOne
    @JoinColumn(name = "id_liga")
    private Liga liga;

    @ManyToOne
    @JoinColumn(name = "id_equipo_local")
    private Equipo equipoLocal;

    @ManyToOne
    @JoinColumn(name = "id_equipo_visitante")
    private Equipo equipoVisitante;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_partido;

    @Column
    private String fecha_partido;

    @Column
    private int goles_equipo_local;

    @Column
    private int goles_equipo_visitante;


    // Constructor para crear partidos.
    public Partido(String fecha_partido, int goles_equipo_local, int goles_equipo_visitante) {

        this.fecha_partido = fecha_partido;
        this.goles_equipo_local = goles_equipo_local;
        this.goles_equipo_visitante = goles_equipo_visitante;
    }



}

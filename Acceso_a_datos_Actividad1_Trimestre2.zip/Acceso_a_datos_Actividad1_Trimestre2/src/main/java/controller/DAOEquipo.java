package controller;

import database.HibernateUtil;
import model.Equipo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DAOEquipo {

    private SessionFactory sessionFactory;

    public DAOEquipo(){sessionFactory=HibernateUtil.getSessionFactory();}
    public void registrarEquipo(Equipo equipo){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.persist(equipo);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
    public void modificarEquipo(Equipo equipo){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.update(equipo);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
    public void eliminarEquipo(Equipo equipo){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.delete(equipo);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
}

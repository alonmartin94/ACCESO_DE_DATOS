package controller;

import database.HibernateUtil;
import model.Partido;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import java.util.List;

public class DAOPartido {

    private SessionFactory sessionFactory;

    public DAOPartido(){sessionFactory= HibernateUtil.getSessionFactory();}

    public void regisatrarPartido(Partido partido){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.persist(partido);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
    public void asignarResultadoPartido(Partido partido) {
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // update
        session.update(partido);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }

    public List<Partido> consultarPartidosResultados() {
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // query para obtener todos los partidos
        Query<Partido> query = session.createQuery("FROM Partido", Partido.class);
        List<Partido> partidos = query.getResultList();
        // commit
        session.getTransaction().commit();
        // close
        session.close();
        return partidos;
    }

}

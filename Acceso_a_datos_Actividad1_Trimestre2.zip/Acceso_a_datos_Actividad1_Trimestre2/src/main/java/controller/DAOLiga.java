package controller;

import database.HibernateUtil;
import model.Equipo;
import model.Liga;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DAOLiga {

    private SessionFactory sessionFactory;

    public DAOLiga(){sessionFactory=HibernateUtil.getSessionFactory();}

    public void crearLiga(Liga liga){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.persist(liga);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
    public void editarLiga(Liga liga){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.update(liga);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }
    public void eliminarLiga(Liga liga){
        // session
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        // persit, list, update, delete, HQL
        session.delete(liga);
        // commit
        session.getTransaction().commit();
        // close
        session.close();
    }





}
